(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["friends-friends-module"],{

/***/ "./src/app/friend.ts":
/*!***************************!*\
  !*** ./src/app/friend.ts ***!
  \***************************/
/*! exports provided: Friend */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Friend", function() { return Friend; });
var Friend = /** @class */ (function () {
    function Friend() {
        this.name = ''; // <- Actual friend name
        this.user = ''; // <- My user name to identify myfriends
    }
    return Friend;
}());



/***/ }),

/***/ "./src/app/friends/friends.module.ts":
/*!*******************************************!*\
  !*** ./src/app/friends/friends.module.ts ***!
  \*******************************************/
/*! exports provided: FriendsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FriendsPageModule", function() { return FriendsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _friends_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./friends.page */ "./src/app/friends/friends.page.ts");







var routes = [
    {
        path: "",
        component: _friends_page__WEBPACK_IMPORTED_MODULE_6__["FriendsPage"]
    }
];
var FriendsPageModule = /** @class */ (function () {
    function FriendsPageModule() {
    }
    FriendsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_friends_page__WEBPACK_IMPORTED_MODULE_6__["FriendsPage"]]
        })
    ], FriendsPageModule);
    return FriendsPageModule;
}());



/***/ }),

/***/ "./src/app/friends/friends.page.html":
/*!*******************************************!*\
  !*** ./src/app/friends/friends.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"secondary\">\n    <ion-title class=\"title\">Friends</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"body\">\n  <div class=\"card card-5\">\n    <h1>Add Friend</h1>\n  </div>\n\n  <br />\n  <div class=\"card card-5\">\n    <ion-item>\n      <ion-label>\n        <h2>Friends Name:</h2>\n      </ion-label>\n      <ion-input [(ngModel)]=\"friendName\" class=\"input\"></ion-input>\n    </ion-item>\n  </div>\n\n  <ion-button\n    (click)=\"register()\"\n    color=\"primary\"\n    size=\"small\"\n    class=\"button button-medium button-positive\"\n    id=\"button\"\n  >\n    <ion-icon slot=\"start\" name=\"send\"></ion-icon>\n    Save Friend\n  </ion-button>\n\n  <br /><br />\n  <div class=\"card card-5\">\n    <h1>Friends</h1>\n  </div>\n\n  <div>\n    <ion-list>\n      <ion-item *ngFor=\"let friend of friendList\" class=\"card card-5\">\n        <ion-label>\n          <h3>{{ friend.name }}</h3>\n        </ion-label>\n      </ion-item>\n    </ion-list>\n  </div>\n\n  <div class=\"img\">\n    <P></P>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/friends/friends.page.scss":
/*!*******************************************!*\
  !*** ./src/app/friends/friends.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h3 {\n  color: white;\n  font-size: 25px;\n  font-weight: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZnJpZW5kcy9DOlxcVXNlcnNcXHR5bGVyXFxEZXNrdG9wXFxDb2RlIEZsYXNoIERyaXZlXFxGU0RJXFwxMDlcXFBPU1Qvc3JjXFxhcHBcXGZyaWVuZHNcXGZyaWVuZHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBWTtFQUNaLGVBQWU7RUFDZixpQkFBaUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2ZyaWVuZHMvZnJpZW5kcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMyB7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGZvbnQtc2l6ZTogMjVweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/friends/friends.page.ts":
/*!*****************************************!*\
  !*** ./src/app/friends/friends.page.ts ***!
  \*****************************************/
/*! exports provided: FriendsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FriendsPage", function() { return FriendsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared.service */ "./src/app/shared.service.ts");
/* harmony import */ var _friend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../friend */ "./src/app/friend.ts");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");





var FriendsPage = /** @class */ (function () {
    function FriendsPage(shared, data) {
        var _this = this;
        this.shared = shared;
        this.data = data;
        this.friendName = '';
        this.friendList = [];
        var myUserName = this.shared.getUserName();
        this.data.getFriends().subscribe(function (list) {
            _this.friendList = []; // clear prev data
            for (var i = 0; i < list.length; i++) {
                var f = list[i];
                if (f.user == myUserName) {
                    _this.friendList.push(f);
                }
            }
        });
    }
    FriendsPage.prototype.ngOnInit = function () { };
    /*saveFriend() {
      console.log('Saving new friend');
      this.shared.saveNewFriend(this.friendName);
      //this.friendList.push(this.friendName); posting second time
      this.friendName = '';
    }
  */
    FriendsPage.prototype.register = function () {
        var friend = new _friend__WEBPACK_IMPORTED_MODULE_3__["Friend"]();
        friend.name = this.friendName;
        friend.user = this.shared.getUserName();
        this.data.saveFriend(friend);
        this.friendName = '';
    };
    FriendsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-friends',
            template: __webpack_require__(/*! ./friends.page.html */ "./src/app/friends/friends.page.html"),
            styles: [__webpack_require__(/*! ./friends.page.scss */ "./src/app/friends/friends.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"], _data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]])
    ], FriendsPage);
    return FriendsPage;
}());



/***/ })

}]);
//# sourceMappingURL=friends-friends-module.js.map