import { Component } from '@angular/core';
import { Message } from '../message';
import { DataService } from '../data.service';
import { SharedService } from '../shared.service';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  postTest = '';
  imageUrl = '';
  friends = [];
  to = 'Everyone';
 

  constructor(private dataSrv: DataService, private shared: SharedService) {
    var myUserName = this.shared.getUserName();
    this.dataSrv.getFriends().subscribe(list => {
      this.friends = []; // clear prev data
      for (var i = 0; i < list.length; i++) {
        var f = list[i];
        if (f.user == myUserName) {
          this.friends.push(f);
        }
      }
    })
  }

  createPost() {
    // create a message obj
    var m = new Message();
    m.text = this.postTest;
    m.imageUrl = this.imageUrl;
    m.from = this.shared.getUserName();
    m.to = this.to;

    this.dataSrv.postMessage(m);

    console.log('Creating the post', m);

    // clean controls
    this.postTest = '';
    this.imageUrl = '';

  }

}
