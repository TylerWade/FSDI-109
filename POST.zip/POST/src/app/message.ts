import { SharedService } from './shared.service';

export class Message {
    public text: String = '';
    public imageUrl: String = '';
    public createdOn: Date;
    public from: String = '';
    public to: String = '';

    constructor() {
        this.to = "Everyone";
        this.createdOn = new Date(); // current date and time

    }
}


/**
 * IDEA - Be able to change the username on a config page on the app
 * 
 * create - the form on the config page(tab3)
 * create - the service (ionic generate service shared)
 * store the value from the form into the shareService
 * reate the userName from the sharedService
 * 
 */