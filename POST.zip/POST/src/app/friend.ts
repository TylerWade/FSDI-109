export class Friend {
    public name : String = ''; // <- Actual friend name
    public user : String = ''; // <- My user name to identify myfriends
}
