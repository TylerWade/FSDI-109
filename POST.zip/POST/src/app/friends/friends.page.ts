import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';
import { Friend } from '../friend';
import { DataService } from '../data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.page.html',
  styleUrls: ['./friends.page.scss'],
})
export class FriendsPage implements OnInit {
  friendName = '';
  friendList: Friend[] = [];

  constructor(private shared: SharedService, private data : DataService) {
    var myUserName = this.shared.getUserName();
    this.data.getFriends().subscribe(list => {
      this.friendList = []; // clear prev data
      for( var i=0; i < list.length; i++){
        var f = list[i];
        if(f.user == myUserName){
          this.friendList.push(f);
        }
      }
    });
  }

  ngOnInit() { }

  /*saveFriend() {
    console.log('Saving new friend');
    this.shared.saveNewFriend(this.friendName);
    //this.friendList.push(this.friendName); posting second time
    this.friendName = '';
  }
*/

  register() {
    var friend = new Friend();
    friend.name = this.friendName;
    friend.user = this.shared.getUserName();
    this.data.saveFriend(friend);

    this.friendName = '';
  }
}
